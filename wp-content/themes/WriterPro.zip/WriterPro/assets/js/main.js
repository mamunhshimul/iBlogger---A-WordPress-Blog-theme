// writer preloader
window.addEventListener("load", function(){
    document.querySelector(".writer-preloader").classList.remove('active')
});
